﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using GameUtility;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;

namespace MonoProgram;

static class Spacetime
{
	public const int PLANE_WIDTH = 1800;
	public const int PLANE_HEIGHT = 1125;

	public const int AXIS_SCALE = 25;

	public const int X_WIDTH = PLANE_WIDTH / AXIS_SCALE;
	public const int T_HEIGHT = PLANE_HEIGHT / AXIS_SCALE;
}

public struct Event
{
	public float x;
	public float t;

	public Event(float x, float t)
	{
		this.x = x;
		this.t = t;
	}
}

public class Worldline
{
	public Func<float, float> XofT;

	public Color color;

	public float tStart;
	public float xStart;
}

public class Observer
{
	public float gamma;

	public List<WorldlineSegment> segments = new List<WorldlineSegment>();

	public Observer(float velocity, float startPosition, float startTime, Color color)
	{
		gamma = 1f / MathF.Sqrt(1 - velocity * velocity);

		segments.Add(new WorldlineSegment
		{
			tStart = startTime,
			tEnd = float.MaxValue,
			xStart = startPosition,
			v = velocity,
			color = color
		});
	}
}

public struct ManeuverNode
{
	public float t;
	public float deltaV;

	public ManeuverNode(float t, float deltaV)
	{
		this.t = t;
		this.deltaV = deltaV;
	}
}

public struct WorldlineSegment
{
	public float tStart;
	public float tEnd;

	public float xStart;
	public float v;

	public Color color;
}

public class Game1 : Game
{
	const int SCREEN_WIDTH = 1920;
	const int SCREEN_HEIGHT = 1200;

	static Random rng = new Random();

	KeyboardState kb;
	KeyboardState prevKb;

	MouseState mouse;
	MouseState prevMouse;

	SpriteFont smallFont;
	SpriteFont medFont;
	SpriteFont largeFont;
	SpriteFont americanFont;

	Texture2D pixel;

	List<Observer> observers = new List<Observer>();
	List<Event> events = new List<Event>();
	List<ManeuverNode> maneuverNodes = new List<ManeuverNode>();

	float GetFrameVelocity(float t)
	{
		float v = 0f;

		for (int i = 0; i < maneuverNodes.Count; i++)
		{
			if (t >= maneuverNodes[i].t)
			{
				v = (v + maneuverNodes[i].deltaV) / (1f + v * maneuverNodes[i].deltaV);
			}
		}

		return v;
	}

	float frameVelocity = 0;
	float frameOriginX = 0;
	float frameOriginT = 0;
	float keyPressMult = 1f;
	float currentTime = 0f;

	int currentLevel;

	private GraphicsDeviceManager _graphics;
	private SpriteBatch _spriteBatch;

	public Game1()
	{
		_graphics = new GraphicsDeviceManager(this);
		Content.RootDirectory = "Content";
		IsMouseVisible = true;
	}

	protected override void Initialize()
	{
		_graphics.PreferredBackBufferWidth = SCREEN_WIDTH;
		_graphics.PreferredBackBufferHeight = SCREEN_HEIGHT;
		_graphics.SynchronizeWithVerticalRetrace = false;
		IsFixedTimeStep = true;

		_graphics.ApplyChanges();
		base.Initialize();
	}

	protected override void LoadContent()
	{
		_spriteBatch = new SpriteBatch(GraphicsDevice);

		pixel = Content.Load<Texture2D>("Images/Sprites/pixel");

		smallFont = Content.Load<SpriteFont>("Fonts/SmallFont");
		medFont = Content.Load<SpriteFont>("Fonts/MedFont");
		largeFont = Content.Load<SpriteFont>("Fonts/LargeFont");
		americanFont = Content.Load<SpriteFont>("Fonts/AmericanFont");

		currentLevel = 1;

		Observer restObserver = new Observer(0, 0, 0, Color.Red);
		Observer slowObserver = new Observer(0f, -10, 5, Color.Cyan);
		Observer fastObserver = new Observer(0.8f, 0, 0, Color.Green);
		Observer photon1 = new Observer(1, 0, 0, Color.Yellow);
		Observer photon2 = new Observer(-1, 0, 0, Color.Yellow);

		observers.Add(restObserver);
		observers.Add(slowObserver);
		observers.Add(fastObserver);
		observers.Add(photon1);
		observers.Add(photon2);

		Event e = new Event(5, 10);

		events.Add(e);
	}

	protected override void Update(GameTime gameTime)
	{
		prevKb = kb;
		kb = Keyboard.GetState();

		prevMouse = mouse;
		mouse = Mouse.GetState();

		if (kb.IsKeyDown(Keys.Z) && !prevKb.IsKeyDown(Keys.Z))
		{
			if (keyPressMult < 32)
			{
				keyPressMult *= 2;
			}
		}

		if (kb.IsKeyDown(Keys.X) && !prevKb.IsKeyDown(Keys.X))
		{
			if (keyPressMult > 0.03125)
			{
				keyPressMult /= 2;
			}
		}

		if (kb.IsKeyDown(Keys.E))
		{
			frameVelocity += 0.002f * keyPressMult;
		}
		if (kb.IsKeyDown(Keys.Q))
		{
			frameVelocity -= 0.002f * keyPressMult;
		}
		if (kb.IsKeyDown(Keys.D))
		{
			frameOriginX += 0.05f * keyPressMult;
		}
		if (kb.IsKeyDown(Keys.A))
		{
			frameOriginX -= 0.05f * keyPressMult;
		}
		if (kb.IsKeyDown(Keys.W))
		{
			frameOriginT += 0.05f * keyPressMult;
		}
		if (kb.IsKeyDown(Keys.S))
		{
			frameOriginT -= 0.05f * keyPressMult;
		}
		if (kb.IsKeyDown(Keys.F))
		{
			currentTime += 0.05f * keyPressMult;
		}
		if (kb.IsKeyDown(Keys.G))
		{
			currentTime -= 0.05f * keyPressMult;
		}
		if (kb.IsKeyDown(Keys.R))
		{
			frameVelocity = 0;
			frameOriginX = 0;
			frameOriginT = 0;
			currentTime = 0;
		}

		if (kb.IsKeyDown(Keys.O) && !prevKb.IsKeyDown(Keys.O))
		{
			bool found = false;
			for (int i = 0; i < maneuverNodes.Count; i++)
			{
				if (maneuverNodes[i].t == currentTime)
				{
					ManeuverNode m = maneuverNodes[i];
					m.deltaV += 0.1f;
					maneuverNodes[i] = m;
					found = true;
					break;
				}
			}
			if (!found)
			{
				maneuverNodes.Add(new ManeuverNode(currentTime, 0.1f));
			}
		}

		if (kb.IsKeyDown(Keys.P) && !prevKb.IsKeyDown(Keys.P))
		{
			bool found = false;
			for (int i = 0; i < maneuverNodes.Count; i++)
			{
				if (maneuverNodes[i].t == currentTime)
				{
					ManeuverNode m = maneuverNodes[i];
					m.deltaV -= 0.1f;
					maneuverNodes[i] = m;
					found = true;
					break;
				}
			}
			if (!found)
			{
				maneuverNodes.Add(new ManeuverNode(currentTime, -0.1f));
			}
		}

		frameVelocity = Math.Clamp(frameVelocity, -0.99f, 0.99f);
		frameOriginX = Math.Clamp(frameOriginX, -Spacetime.X_WIDTH / 2, Spacetime.X_WIDTH / 2);
		frameOriginT = Math.Clamp(frameOriginT, -Spacetime.T_HEIGHT / 2, Spacetime.T_HEIGHT / 2);

		base.Update(gameTime);
	}

	protected override void Draw(GameTime gameTime)
	{
		GraphicsDevice.Clear(Color.Black);

		_spriteBatch.Begin();

		for (int x = -Spacetime.X_WIDTH / 2; x <= Spacetime.X_WIDTH / 2; x++)
		{
			DrawLine(WorldToScreenUI(x, -2), WorldToScreenUI(x, Spacetime.T_HEIGHT), 1, Color.DimGray);
		}

		for (int t = -1; t <= Spacetime.T_HEIGHT; t++)
		{
			DrawLine(WorldToScreenUI(-Spacetime.X_WIDTH / 2, t), WorldToScreenUI(Spacetime.X_WIDTH / 2, t), 1, Color.DimGray);
		}

		DrawLine(WorldToScreenUI(-Spacetime.X_WIDTH / 2f, 0), WorldToScreenUI(Spacetime.X_WIDTH / 2f, 0), 2, Color.White);
		DrawLine(WorldToScreenUI(0, 0), WorldToScreenUI(0, Spacetime.T_HEIGHT), 2, Color.White);

		for (int i = -Spacetime.X_WIDTH / 2; i < Spacetime.X_WIDTH / 2; i++)
		{
			if (i % 5 == 0)
			{
				_spriteBatch.DrawString(smallFont, i.ToString(), WorldToScreenUI(i + 0.1f, 0), Color.White);
			}
		}

		for (int i = 0; i < Spacetime.T_HEIGHT; i++)
		{
			if (i % 5 == 0)
			{
				_spriteBatch.DrawString(smallFont, i.ToString(), WorldToScreenUI(0.1f, i), Color.White);
			}
		}

		for (int i = 0; i < events.Count; i++)
		{
			DrawEvent(events[i], Color.Pink);
		}

		for (int i = 0; i < observers.Count; i++)
		{
			DrawSimultaneity(observers[i], currentTime);
			DrawTicks(observers[i], observers[i].worldline.color);
			DrawWorldline(observers[i]);
		}

		_spriteBatch.DrawString(medFont, "Mult: " + keyPressMult, new Vector2(20, SCREEN_HEIGHT - 280), Color.White);
		_spriteBatch.DrawString(medFont, "V Relative to Rest Frame: " + Math.Round(GetFrameVelocity(currentTime), 2), new Vector2(20, SCREEN_HEIGHT - 240), Color.White);
		_spriteBatch.DrawString(medFont, "X Relative to Rest Frame: " + Math.Round(GetJudgePosition(currentTime).X, 2), new Vector2(20, SCREEN_HEIGHT - 200), Color.White);
		_spriteBatch.DrawString(medFont, "T Relative to Rest Frame: " + Math.Round(frameOriginT, 2), new Vector2(20, SCREEN_HEIGHT - 160), Color.White);
		_spriteBatch.DrawString(medFont, "Observers' Proper Time: " + Math.Round(currentTime, 2), new Vector2(20, SCREEN_HEIGHT - 120), Color.White);

		_spriteBatch.End();

		base.Draw(gameTime);
	}

	void DrawLine(Vector2 start, Vector2 end, float thickness, Color color)
	{
		Vector2 edge = end - start;
		float angle = (float)Math.Atan2(edge.Y, edge.X);
		float length = edge.Length();

		_spriteBatch.Draw(pixel, start, null, color, angle, new Vector2(0f, 0.5f), new Vector2(length, thickness), SpriteEffects.None, 0f);
	}

	void DrawTicks(Observer obs, Color color)
	{
		float properStep = 1f;
		float tickLength = 10f;

		float tauMax = Spacetime.T_HEIGHT * 5f / obs.gamma;

		float x0 = obs.worldline.xStart;
		float t0 = obs.worldline.tStart;

		if (obs.worldline.tStart < 0)
		{
			t0 = -2 * Spacetime.AXIS_SCALE;
		}

		int tickIndex = 0;

		for (float tau = 0f; tau <= tauMax; tau += properStep)
		{
			float t = t0 + obs.gamma * tau;
			float x = x0 + obs.v * (t - t0);

			Vector2 p1 = WorldToScreen(x, t);
			Vector2 p2 = WorldToScreen(x + obs.v, t + 1f);

			Vector2 tangent = p2 - p1;
			tangent.Normalize();

			Vector2 normal = new Vector2(-tangent.Y, tangent.X);

			Vector2 start = p1 - normal * tickLength * 0.5f;
			Vector2 end = p1 + normal * tickLength * 0.5f;

			if (end.X < Spacetime.PLANE_WIDTH && start.X >= 0 && end.Y < Spacetime.PLANE_HEIGHT && start.Y < Spacetime.PLANE_HEIGHT)
			{
				DrawLine(start, end, 2f, color);

				if (tickIndex % 5 == 0)
				{
					string label;

					if (obs.worldline.tStart >= 0)
					{
						label = tau.ToString();
					}
					else
					{
						label = (tau - 50).ToString();
					}

					Vector2 textOffset = tangent * 8f + normal * 8f + new Vector2(-5, -5);
					Vector2 textPos = p1 + textOffset;

					_spriteBatch.DrawString(smallFont, label, textPos, Color.White);
					_spriteBatch.DrawString(smallFont, label, textPos, color);
				}
			}

			tickIndex++;
		}
	}

	void DrawEvent(Event e, Color color)
	{
		Vector2 p = WorldToScreen(e.x, e.t);

		if (e.x < Spacetime.PLANE_WIDTH)
		{
			_spriteBatch.Draw(pixel, new Rectangle((int)p.X - 3, (int)p.Y - 3, 6, 6), color);
		}
	}

	void DrawWorldline(Observer obs)
	{
		foreach (var seg in obs.segments)
		{
			float dtStep = 0.1f;

			for (float t = seg.tStart; t < seg.tEnd; t += dtStep)
			{
				float x1 = seg.xStart + seg.v * (t - seg.tStart);
				float x2 = seg.xStart + seg.v * (t + dtStep - seg.tStart);

				Vector2 p1 = WorldToScreen(x1, t);
				Vector2 p2 = WorldToScreen(x2, t + dtStep);

				DrawLine(p1, p2, 2f, seg.color);
			}
		}
	}

	public static float TransformVelocity(float v, float frameV)
	{
		return (v - frameV) / (1 - v * frameV);
	}

	Vector2 WorldToScreenUI(double x, double t)
	{
		float screenX = Spacetime.PLANE_WIDTH / 2f + (float)x * Spacetime.AXIS_SCALE;
		float screenY = Spacetime.PLANE_HEIGHT - (float)t * Spacetime.AXIS_SCALE;

		return new Vector2(screenX, screenY);
	}

	Vector2 WorldToScreen(float x, float t)
	{
		Event e = new Event(x, t);

		float v = GetFrameVelocity(currentTime);
		Vector2 judge = GetJudgePosition(currentTime);

		float dx = e.x - judge.X;
		float dt = e.t - judge.Y;

		float gamma = 1f / MathF.Sqrt(1 - v * v);

		float xPrime = gamma * (dx - v * dt);
		float tPrime = gamma * (dt - v * dx);

		float screenX = xPrime * Spacetime.AXIS_SCALE + Spacetime.PLANE_WIDTH / 2;
		float screenY = Spacetime.PLANE_HEIGHT - tPrime * Spacetime.AXIS_SCALE;

		return new Vector2(screenX, screenY);
	}

	Event LorentzTransform(Event e)
	{
		float gamma = 1f / MathF.Sqrt(1 - GetFrameVelocity(currentTime) * GetFrameVelocity(currentTime));

		float dx = e.x - GetJudgePosition(currentTime).X;
		float dt = e.t - frameOriginT;

		float xPrime = gamma * (dx - GetFrameVelocity(currentTime) * dt);
		float tPrime = gamma * (dt - GetFrameVelocity(currentTime) * dx);

		return new Event(xPrime, tPrime);
	}

	void DrawSimultaneity(Observer obs, float currentTime)
	{
		float v = obs.v;
		float gamma = obs.gamma;

		float tau = currentTime;

		float xMin = -Spacetime.PLANE_WIDTH / Spacetime.AXIS_SCALE * 2;
		float xMax = Spacetime.PLANE_WIDTH / Spacetime.AXIS_SCALE * 2;

		float sampleStep = 0.05f;
		float dashLength = 12f;

		float tAnchor = obs.worldline.tStart + gamma * tau;
		float xAnchor = obs.worldline.xStart + v * (tAnchor - obs.worldline.tStart);

		Vector2 anchorScreen = WorldToScreen(xAnchor, tAnchor);

		Vector2? prev = null;

		for (float x = xMin; x <= xMax; x += sampleStep)
		{
			float t = v * x + tau / gamma + obs.worldline.tStart;

			Vector2 p = WorldToScreen(x, t);

			if (prev != null)
			{
				float segmentLength = Vector2.Distance(prev.Value, p);

				float phase = Vector2.Distance(anchorScreen, p) % (dashLength * 2f);

				bool drawSegment = phase < dashLength;

				if (drawSegment && p.X < Spacetime.PLANE_WIDTH && p.Y < Spacetime.PLANE_HEIGHT && Math.Abs(obs.v) != 1)
				{
					DrawLine(prev.Value, p, 2f, obs.worldline.color);
				}
			}

			prev = p;
		}
	}

	Vector2 GetJudgePosition(float t)
	{
		float x = 0f;
		float lastT = 0f;
		float v = 0f;

		for (int i = 0; i < maneuverNodes.Count; i++)
		{
			if (maneuverNodes[i].t > t)
			{
				break;
			}
			float dt = maneuverNodes[i].t - lastT;

			x += v * dt;

			v = (v + maneuverNodes[i].deltaV) / (1f + v * maneuverNodes[i].deltaV);

			lastT = maneuverNodes[i].t;
		}

		x += v * (t - lastT);

		return new Vector2(x, 0f);
	}

	void AddManeuver(Observer obs, float t, float deltaV)
	{
		var segments = obs.segments;

		for (int i = 0; i < segments.Count; i++)
		{
			if (t < segments[i].tStart || t > segments[i].tEnd)
			{
				continue;
			}

			WorldlineSegment old = segments[i];

			WorldlineSegment before = old;
			WorldlineSegment after = old;

			before.tEnd = t;

			after.tStart = t;
			after.v = (old.v + deltaV) / (1f + old.v * deltaV);
			after.xStart = old.xStart + old.v * (t - old.tStart);

			segments[i] = before;
			segments.Add(after);

			break;
		}
	}
}
